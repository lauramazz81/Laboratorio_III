/*
    Objetivo:
        Ir a la definición de la función saludar rápidamente

    Tips:
        Ojear definición   ⌥ F12
        Ir a la definición F12

        Ojear definición   Alt + F12
        Ir a la definición F12
*/

import { saludar } from './extra/funciones';

const saludo = saludar( 'Thanos' );

console.log(saludo);
