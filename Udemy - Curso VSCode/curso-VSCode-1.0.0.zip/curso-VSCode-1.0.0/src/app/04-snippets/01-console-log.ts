







// Ejemplo final
console.log('hola mundo');





