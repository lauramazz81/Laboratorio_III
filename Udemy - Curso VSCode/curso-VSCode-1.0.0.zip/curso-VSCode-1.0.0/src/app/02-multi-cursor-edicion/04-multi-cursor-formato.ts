/*
    Objetivo:
        Crear múltiples cursores
        Dar el formato deseado

    Tips:
        ⇧ ⌥ ↑ / ↓
        Ctrl + Alt+ ↑ / ↓
*/

const hulk = 'brouce banner';
const Hawkeye = 'cinton francis';
const ironman = 'tony stark';
const spiderman = 'peter parker';
const viudaNegra = 'natalia romanova';


// Objetivo final (sin los comentarios)
// const hulk       = 'brouce banner';
// const Hawkeye    = 'cinton francis';
// const ironman    = 'tony stark';
// const spiderman  = 'peter parker';
// const viudaNegra = 'natalia romanova';
