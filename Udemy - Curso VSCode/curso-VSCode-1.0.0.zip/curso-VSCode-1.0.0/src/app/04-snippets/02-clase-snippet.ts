






// Ejemplo final
export class NuevoSuperHeroe {

    constructor() {

    }
}






