// Color highlight

const colores = ['#fafafa', '#7F4CCC', '#0075FF', '#FF5F45'];


